// Plantilla de c�digo para la pr�ctica de laboratorio #4 de Microprocesadores
// Eduardo Corpe�o
// Universidad Galileo, FISICC

#include "LPC11xx.h"

#define MASK(x) (1UL << (x))

int main(void){
  // escriba su c�digo aqu�
}

// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
